What is PowerShell?

    PowerShell is a task automation framework for Windows that allows you to automate system management tasks and run scripts.

What this PowerShell script does:

    It prints messages to the console.
    Creates a directory called MyNewDirectory.
    Changes to that directory.
    Creates a text file (testfile.txt).
    Lists the contents of the directory.

Creating Your First PowerShell Script:

  1. Open PowerShell (or the Windows command prompt).
  2. Create a new script file: "New-Item -ItemType File -Name "MyFirstScript.ps1"
  3. Edit the script (open the .ps1 file in any text editor): notepad MyFirstScript.ps1

Add the following content to the script:
{
Write-Host "Hello, this is my first PowerShell script!"
Write-Host "I am learning how to write scripts in PowerShell."

# Create a directory
New-Item -ItemType Directory -Name "MyNewDirectory"
Write-Host "A new directory 'MyNewDirectory' has been created."

# Change into that directory
Set-Location -Path ".\MyNewDirectory"
Write-Host "You are now in the 'MyNewDirectory' directory."

# Create a simple text file
"This is a test file" | Out-File -FilePath "testfile.txt"
Write-Host "A text file 'testfile.txt' has been created."

# List the contents of the directory
Get-ChildItem
}

Save the file and run the script: In PowerShell, execute it like this:
.\MyFirstScript.ps1