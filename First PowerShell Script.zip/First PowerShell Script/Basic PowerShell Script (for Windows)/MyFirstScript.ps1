Write-Host "Hello, this is my first PowerShell script!"
Write-Host "I am learning how to write scripts in PowerShell."

# Create a directory
New-Item -ItemType Directory -Name "MyNewDirectory"
Write-Host "A new directory 'MyNewDirectory' has been created."

# Change into that directory
Set-Location -Path ".\MyNewDirectory"
Write-Host "You are now in the 'MyNewDirectory' directory."

# Create a simple text file
"This is a test file" | Out-File -FilePath "testfile.txt"
Write-Host "A text file 'testfile.txt' has been created."

# List the contents of the directory
Get-ChildItem