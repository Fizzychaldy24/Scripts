# List of servers to ping
$servers = @("192.168.1.1", "google.com", "8.8.8.8")

foreach ($server in $servers) {
    Write-Host "Pinging $server..."
    $pingResult = Test-Connection -ComputerName $server -Count 1 -Quiet
    if ($pingResult) {
        Write-Host "$server is reachable."
    } else {
        Write-Host "$server is unreachable."
    }
}
