Get Basic System Information
This script retrieves basic system information like the OS version, CPU, memory, and disk space.

Script:
# Get OS Information
$os = Get-CimInstance -ClassName Win32_OperatingSystem
Write-Host "OS: $($os.Caption)"
Write-Host "Version: $($os.Version)"
Write-Host "Architecture: $($os.OSArchitecture)"

# Get CPU Information
$cpu = Get-CimInstance -ClassName Win32_Processor
Write-Host "CPU: $($cpu.Name)"

# Get Total Physical Memory
$memory = Get-CimInstance -ClassName Win32_ComputerSystem
Write-Host "Total Physical Memory: $([math]::round($memory.TotalPhysicalMemory / 1GB, 2)) GB"

# Get Disk Space Information
$disks = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType=3"
$disks | ForEach-Object {
    Write-Host "$($_.DeviceID): $([math]::round($_.Size / 1GB, 2)) GB Total, $([math]::round($_.FreeSpace / 1GB, 2)) GB Free"
}
