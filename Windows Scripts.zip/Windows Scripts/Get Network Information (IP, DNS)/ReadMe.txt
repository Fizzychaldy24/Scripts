Get Network Information (IP, DNS)
This script retrieves the computer's IP address and DNS information.

# Get IP Address
$ipConfig = Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.InterfaceAlias -ne "Loopback" }
Write-Host "IP Address: $($ipConfig.IPAddress)"

# Get DNS Servers
$dnsServers = Get-DnsClientServerAddress | Where-Object {$_.InterfaceAlias -ne "Loopback"}
Write-Host "DNS Servers: $($dnsServers.ServerAddresses -join ', ')"
