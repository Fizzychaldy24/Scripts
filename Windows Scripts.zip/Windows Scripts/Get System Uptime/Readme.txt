Get System Uptime
This script shows how long the system has been running.

# Get system uptime
$uptime = (Get-CimInstance -ClassName Win32_OperatingSystem).LastBootUpTime
$uptimeFormatted = (Get-Date) - $uptime
Write-Host "System Uptime: $($uptimeFormatted.Days) days, $($uptimeFormatted.Hours) hours, $($uptimeFormatted.Minutes) minutes"
