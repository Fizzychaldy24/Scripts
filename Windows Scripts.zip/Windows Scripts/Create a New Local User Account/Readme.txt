This script creates a new local user account on the machine.

# Prompt for username and password
$username = Read-Host "Enter the username"
$password = Read-Host "Enter the password" -AsSecureString

# Create the new user
New-LocalUser -Name $username -Password $password -FullName "$username User" -Description "New User Account" -AccountNeverExpires

# Add the new user to the 'Users' group
Add-LocalGroupMember -Group "Users" -Member $username

Write-Host "User $username created and added to the Users group."
